# Notepad 98 1.7.3 - 8BitTrade

Plain-text Android notepad with 17 themes. No ads, analytics, accounts, or internet permission.

## Version 1.7.2
Basic revision.

## Install
Open the APK on Android 8 or newer. This package is com.eightbittrade.notepad98. Android treats a different package ID as a separate app. Save any unsaved note in your previous app, then open that .txt file here. Preferences and recovery drafts do not migrate automatically.

## Build
Requires JDK 17, Android SDK platform 35 and build-tools 35.0.0. Set ANDROID_SDK_ROOT, NOTEPAD_KEYSTORE, NOTEPAD_STORE_PASS and NOTEPAD_KEY_PASS, then run ./build.sh. Supply your own private signing keystore. No signing keys or passwords are included in this archive. Your own key will create a differently signed build.

## Usage
File offers New, Open, Save, Save As and Rename. Draft recovery stays on the device. Files are UTF-8 plain text; save explicitly to retain notes outside the app. Open supports up to 8 MB. Format provides font selection, wrapping and text selection. View provides themes and a status-bar toggle. Help contains Restore Defaults, Changelog and About.

Themes are inspired by classic operating systems. This independent app is unaffiliated with Microsoft or Apple. Artwork contains an unused alternate icon; res/drawable/icon.xml is the active launcher icon.

## Verification
Compiled and signature verified. The compiled app was checked for obsolete namespace references. Full device interaction testing was not performed for this revision.

## Changes in 1.7.3
Slightly increased the title bar height so letters like g display fully in every theme. The title adapts to system font scaling. Updates 1.7.2 in place.
